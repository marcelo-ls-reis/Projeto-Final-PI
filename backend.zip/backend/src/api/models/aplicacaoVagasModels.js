const { Model, DataTypes } = require('sequelize');

class AplicacaoVagas extends Model {
    static init(sequelize) {
        super.init({
            apV_idusuario: DataTypes.STRING,
            apV_idvaga: DataTypes.STRING,
            apV_resultaplicacao: DataTypes.STRING
        }, { sequelize });

    }
}

module.exports = AplicacaoVagas;