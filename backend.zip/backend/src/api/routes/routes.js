const express = require('express')
const routes = express.Router()

const controllers = require('../controllers/indexControllers.js')
const usuariosControllers = require('../controllers/usuariosControllers.js')
const cursosControllers = require('../controllers/cursosControllers.js')
const empresasControllers = require('../controllers/empresasControllers.js')
const vagasControllers = require('../controllers/vagasControllers.js')
const aplicacaoVagasControllers = require('../controllers/aplicacaoVagasControllers.js')

// rota raiz
routes.get('/', controllers.indexRaiz)

// rotas de categorias
routes.get('/usuarios', usuariosControllers.index)
// routes.post('/categorias', categoriasControllers.store)
// routes.put('/categorias/:codigo_id', categoriasControllers.update)
// routes.delete('/categorias/:codigo_id', categoriasControllers.delete)
// routes.get('/categorias/:codigo_id', categoriasControllers.indexId)

// rotas de cursos
routes.get('/cursos', cursosControllers.index)

// rotas de empresas
routes.get('/empresas', empresasControllers.index)
// routes.post('/times', timesControllers.store)
// routes.put('/times/:codigo_id', timesControllers.update)
// routes.delete('/times/:codigo_id', timesControllers.delete)

routes.get('/vagas', vagasControllers.index)
routes.get('/aplicacaoVagas', aplicacaoVagasControllers.index)

module.exports = routes

