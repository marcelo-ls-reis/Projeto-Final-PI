const Usuarios = require('../models/usuariosModels.js');

module.exports = {
    
    async index(requisicao, resposta){
        const usuarios = await Usuarios.findAll();
        return resposta.json(usuarios);
    },

}


