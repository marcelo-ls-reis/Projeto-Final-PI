const Cursos = require('../models/cursosModels.js');

module.exports = {
    
    async index(requisicao, resposta){
        const cursos = await Cursos.findAll();
        return resposta.json(cursos);
    },

}


