const aplicacaoVagas = require('../models/aplicacaoVagasModels.js');

module.exports = {
    
    async index(requisicao, resposta){
        const vagas = await aplicacaoVagas.findAll();
        return resposta.json(vagas);
    },

}


