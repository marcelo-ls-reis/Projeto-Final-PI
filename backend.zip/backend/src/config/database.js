module.exports = {
    host: 'localhost',
    dialect: 'mysql',
    username: 'root',
    password: 'fatec123*',
    database: 'webiiorm',
    define: {
        timestamps:true,
        underscored: true,
    },
};

